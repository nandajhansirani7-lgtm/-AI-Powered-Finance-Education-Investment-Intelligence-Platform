import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';
import { useActor } from './useActor';
import type {
  UserProfileInput,
  UserProfileView,
  LearningProgress,
  LearningProgressView,
  Prediction,
  Portfolio,
  Conversation,
  Post,
  NewsArticle,
  Alert,
  PlatformStats,
  LeaderboardEntry,
} from '../backend';
import { Variant_high_critical_medium } from '../backend';
import type { Principal } from '@dfinity/principal';

// ─── User Profile ────────────────────────────────────────────────────────────

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfileView | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfileInput) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ─── Password Management ──────────────────────────────────────────────────────

export function useSetUserPassword() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (passwordHash: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.setUserPassword(passwordHash);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useVerifyUserPassword() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (passwordHash: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.verifyUserPassword(passwordHash);
    },
  });
}

// ─── Learning Progress ────────────────────────────────────────────────────────

export function useGetLearningProgress() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<LearningProgressView | null>({
    queryKey: ['learningProgress'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getLearningProgress();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useSaveLearningProgress() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (progress: LearningProgress) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveLearningProgress(progress);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['learningProgress'] });
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ─── Predictions ──────────────────────────────────────────────────────────────

export function useGetUserPredictions() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Prediction[]>({
    queryKey: ['userPredictions'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getUserPredictions();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useSubmitPrediction() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (prediction: Prediction) => {
      if (!actor) throw new Error('Actor not available');
      return actor.submitPrediction(prediction);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userPredictions'] });
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ─── News Articles ────────────────────────────────────────────────────────────

export function useGetNewsArticles() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<NewsArticle[]>({
    queryKey: ['newsArticles'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getNewsArticles();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useGetNewsArticle(id: bigint) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<NewsArticle | null>({
    queryKey: ['newsArticle', id.toString()],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getNewsArticle(id);
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useAddNewsArticle() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (article: NewsArticle) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addNewsArticleWithScore(article);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['newsArticles'] });
    },
  });
}

export function useInitializeNewsDatabase() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.initializeNewsDatabase();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['newsArticles'] });
    },
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isCallerAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });
}

// ─── Summary Statistics ───────────────────────────────────────────────────────

export function useGetSummaryStatistics() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<{
    negativeCount: bigint;
    positiveCount: bigint;
    neutralCount: bigint;
    averageScore: number;
  } | null>({
    queryKey: ['summaryStatistics'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getSummaryStatistics();
    },
    enabled: !!actor && !actorFetching,
  });
}

// ─── Portfolio ────────────────────────────────────────────────────────────────

export function useGetPortfolio() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Portfolio | null>({
    queryKey: ['portfolio'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getPortfolio();
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useSavePortfolio() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (portfolio: Portfolio) => {
      if (!actor) throw new Error('Actor not available');
      return actor.savePortfolio(portfolio);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['portfolio'] });
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

// ─── Conversation ─────────────────────────────────────────────────────────────

export function useGetConversation() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Conversation | null>({
    queryKey: ['conversation'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getConversation();
    },
    enabled: !!actor && !actorFetching,
    refetchInterval: 3000,
  });
}

export function useSendMessage() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (content: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.sendMessage(content);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['conversation'] });
    },
  });
}

// ─── Forum Posts ──────────────────────────────────────────────────────────────

export function useGetForumPosts(sortByVotes: boolean = false) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<Post[]>({
    queryKey: ['forumPosts', sortByVotes],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getForumPosts(sortByVotes);
    },
    enabled: !!actor && !actorFetching,
  });
}

export function useCreatePost() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ content, symbols }: { content: string; symbols: string[] }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createPost(content, symbols);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
    },
  });
}

export function useUpvotePost() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (index: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.upvotePost(index);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
    },
  });
}

// ─── Market Alerts ────────────────────────────────────────────────────────────

/**
 * Synthesizes a short two-tone chime using the Web Audio API.
 * No external audio files are used.
 */
function playAlertChime(): void {
  try {
    const AudioContextClass =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();

    const playTone = (frequency: number, startTime: number, duration: number, gainPeak: number) => {
      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(frequency, startTime);

      gainNode.gain.setValueAtTime(0, startTime);
      gainNode.gain.linearRampToValueAtTime(gainPeak, startTime + 0.02);
      gainNode.gain.setValueAtTime(gainPeak, startTime + duration * 0.4);
      gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

      oscillator.start(startTime);
      oscillator.stop(startTime + duration);

      oscillator.onended = () => {
        oscillator.disconnect();
        gainNode.disconnect();
      };
    };

    const now = ctx.currentTime;
    playTone(880, now, 0.18, 0.35);
    playTone(1100, now + 0.12, 0.22, 0.28);

    setTimeout(() => {
      ctx.close().catch(() => {});
    }, 600);
  } catch {
    // Silently ignore if Web Audio API is unavailable
  }
}

export function useMarketAlerts() {
  const { actor, isFetching: actorFetching } = useActor();

  const seenAlertIdsRef = useRef<Set<string>>(new Set());
  const isFirstFetchRef = useRef<boolean>(true);

  const query = useQuery<Alert[]>({
    queryKey: ['marketAlerts'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getMarketAlerts();
    },
    enabled: !!actor && !actorFetching,
    refetchInterval: 30000,
  });

  useEffect(() => {
    if (!query.data) return;

    if (isFirstFetchRef.current) {
      query.data.forEach(alert => seenAlertIdsRef.current.add(alert.id.toString()));
      isFirstFetchRef.current = false;
      return;
    }

    let hasNewUrgentAlert = false;
    query.data.forEach(alert => {
      const idStr = alert.id.toString();
      if (!seenAlertIdsRef.current.has(idStr)) {
        seenAlertIdsRef.current.add(idStr);
        const sev = alert.severity as unknown as { high?: null; critical?: null; medium?: null };
        if (Variant_high_critical_medium.critical in sev || Variant_high_critical_medium.high in sev) {
          hasNewUrgentAlert = true;
        }
      }
    });

    if (hasNewUrgentAlert) {
      playAlertChime();
    }
  }, [query.data]);

  return query;
}

// ─── Public Leaderboard ───────────────────────────────────────────────────────

export function useGetPublicLeaderboard() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<LeaderboardEntry[]>({
    queryKey: ['publicLeaderboard'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getPublicLeaderboard();
    },
    enabled: !!actor && !actorFetching,
  });
}

// ─── Admin Hooks ──────────────────────────────────────────────────────────────

export function useAdminGetAllUsers() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<UserProfileView[]>({
    queryKey: ['adminUsers'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminGetAllUsers();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });
}

export function useAdminBanUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (principal: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminBanUser(principal);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
    },
  });
}

export function useAdminUnbanUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (principal: Principal) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminUnbanUser(principal);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminUsers'] });
    },
  });
}

export function useAdminDeletePost() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (postId: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminDeletePost(postId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
    },
  });
}

export function useAdminUpdateNewsArticle() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      title,
      summary,
      sentimentScore,
    }: {
      id: bigint;
      title: string;
      summary: string;
      sentimentScore: number;
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminUpdateNewsArticle(id, title, summary, sentimentScore);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['newsArticles'] });
    },
  });
}

export function useAdminGetPlatformStats() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<PlatformStats>({
    queryKey: ['adminPlatformStats'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.adminGetPlatformStats();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });
}
