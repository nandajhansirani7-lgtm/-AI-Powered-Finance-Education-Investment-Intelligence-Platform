import React, { useState, useMemo } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import {
  useGetCallerUserProfile,
  useAdminGetAllUsers,
  useAdminBanUser,
  useAdminUnbanUser,
  useAdminDeletePost,
  useAdminUpdateNewsArticle,
  useAdminGetPlatformStats,
  useGetForumPosts,
  useGetNewsArticles,
  useGetPublicLeaderboard,
} from '../hooks/useQueries';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  Shield,
  Users,
  MessageSquare,
  Newspaper,
  BarChart2,
  Ban,
  CheckCircle,
  Trash2,
  Edit,
  ChevronLeft,
  ChevronRight,
  Search,
  AlertTriangle,
  TrendingUp,
  FileText,
  Bell,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import type { NewsArticle, Post } from '../backend';
import type { Principal } from '@dfinity/principal';
import { Principal as PrincipalClass } from '@dfinity/principal';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function truncatePrincipal(p: string): string {
  if (p.length <= 16) return p;
  return `${p.slice(0, 8)}…${p.slice(-4)}`;
}

function formatDate(ts: bigint): string {
  const ms = Number(ts) / 1_000_000;
  return new Date(ms).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function formatRelativeTime(ts: bigint): string {
  const ms = Number(ts) / 1_000_000;
  const diff = Date.now() - ms;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

// ─── KPI Card ─────────────────────────────────────────────────────────────────

interface KpiCardProps {
  label: string;
  value: bigint | number | undefined;
  icon: React.ReactNode;
  color: string;
  loading?: boolean;
}

function KpiCard({ label, value, icon, color, loading }: KpiCardProps) {
  return (
    <div className="glass-card rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{label}</span>
        <div className={`p-2 rounded-xl ${color}`}>{icon}</div>
      </div>
      {loading ? (
        <Skeleton className="h-9 w-24" />
      ) : (
        <span className="font-display text-3xl font-bold text-foreground animate-number-tick">
          {value !== undefined ? Number(value).toLocaleString() : '—'}
        </span>
      )}
    </div>
  );
}

// ─── User Management Tab ──────────────────────────────────────────────────────

function UserManagementTab() {
  const { data: users, isLoading, error } = useAdminGetAllUsers();
  const banUser = useAdminBanUser();
  const unbanUser = useAdminUnbanUser();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 20;

  // We don't have principals in UserProfileView, so we work with display names
  const filtered = useMemo(() => {
    if (!users) return [];
    const q = search.toLowerCase();
    return users.filter(u =>
      u.displayName.toLowerCase().includes(q)
    );
  }, [users, search]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  if (error) {
    return (
      <div className="glass-card rounded-2xl p-8 text-center">
        <AlertTriangle className="h-10 w-10 text-destructive mx-auto mb-3" />
        <p className="text-destructive font-medium">Access Denied or Error</p>
        <p className="text-muted-foreground text-sm mt-1">{(error as Error).message}</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by display name…"
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(0); }}
          className="pl-9 bg-secondary/40 border-border/50"
        />
      </div>

      {/* Table */}
      <div className="glass-card rounded-2xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-border/30 hover:bg-transparent">
              <TableHead className="text-muted-foreground">Display Name</TableHead>
              <TableHead className="text-muted-foreground">Accuracy</TableHead>
              <TableHead className="text-muted-foreground">Lessons</TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i} className="border-border/20">
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-20 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : paginated.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground py-10">
                  No users found
                </TableCell>
              </TableRow>
            ) : (
              paginated.map((user, idx) => {
                const globalIdx = page * PAGE_SIZE + idx;
                const isBanned = user.banned;
                const isBanning = banUser.isPending;
                const isUnbanning = unbanUser.isPending;

                return (
                  <TableRow
                    key={globalIdx}
                    className={`border-border/20 transition-opacity ${isBanned ? 'opacity-50' : ''}`}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary">
                          {user.displayName.charAt(0).toUpperCase()}
                        </div>
                        <span className="font-medium text-foreground">{user.displayName}</span>
                        {user.isAdmin && (
                          <Badge variant="outline" className="text-[10px] border-primary/40 text-primary">
                            Admin
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-lime font-mono text-sm">
                        {(user.predictionAccuracy * 100).toFixed(1)}%
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-muted-foreground text-sm">
                        {Number(user.lessonsCompleted)}
                      </span>
                    </TableCell>
                    <TableCell>
                      {isBanned ? (
                        <Badge variant="destructive" className="text-[10px]">Banned</Badge>
                      ) : (
                        <Badge variant="outline" className="text-[10px] border-emerald-500/40 text-emerald-400">
                          Active
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {isBanned ? (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/10 text-xs"
                          disabled={isUnbanning}
                          onClick={() => {
                            // We use display name as identifier since we don't have principal in view
                            toast.info(`Unban action for ${user.displayName} — principal lookup required`);
                          }}
                        >
                          {isUnbanning ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle className="h-3 w-3 mr-1" />}
                          Unban
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-destructive border-destructive/30 hover:bg-destructive/10 text-xs"
                          disabled={isBanning}
                          onClick={() => {
                            toast.info(`Ban action for ${user.displayName} — principal lookup required`);
                          }}
                        >
                          {isBanning ? <Loader2 className="h-3 w-3 animate-spin" /> : <Ban className="h-3 w-3 mr-1" />}
                          Ban
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>
            Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
          </span>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setPage(p => Math.max(0, p - 1))}
              disabled={page === 0}
              className="h-8 w-8 p-0"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="px-2">{page + 1} / {totalPages}</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="h-8 w-8 p-0"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Post Moderation Tab ──────────────────────────────────────────────────────

function PostModerationTab() {
  const { data: posts, isLoading, error } = useGetForumPosts(false);
  const deletePost = useAdminDeletePost();
  const [expandedIdx, setExpandedIdx] = useState<Set<number>>(new Set());

  const toggleExpand = (idx: number) => {
    setExpandedIdx(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  if (error) {
    return (
      <div className="glass-card rounded-2xl p-8 text-center">
        <AlertTriangle className="h-10 w-10 text-destructive mx-auto mb-3" />
        <p className="text-destructive font-medium">Failed to load posts</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="glass-card rounded-2xl p-4">
            <Skeleton className="h-4 w-48 mb-2" />
            <Skeleton className="h-3 w-full mb-1" />
            <Skeleton className="h-3 w-3/4" />
          </div>
        ))}
      </div>
    );
  }

  if (!posts || posts.length === 0) {
    return (
      <div className="glass-card rounded-2xl p-12 text-center">
        <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-40" />
        <p className="text-muted-foreground">No posts to moderate</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {posts.map((post: Post, idx: number) => {
        const isExpanded = expandedIdx.has(idx);
        const content = post.content;
        const truncated = content.length > 200 ? content.slice(0, 200) + '…' : content;
        const isDeleting = deletePost.isPending;

        return (
          <div key={idx} className="glass-card rounded-2xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-xs font-mono text-muted-foreground">
                    {truncatePrincipal(post.author.toString())}
                  </span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-muted-foreground">{formatRelativeTime(post.timestamp)}</span>
                  <span className="text-xs text-muted-foreground">·</span>
                  <span className="text-xs text-lime font-medium">↑ {Number(post.votes)}</span>
                </div>
                <p className="text-sm text-foreground leading-relaxed">
                  {isExpanded ? content : truncated}
                </p>
                {content.length > 200 && (
                  <button
                    onClick={() => toggleExpand(idx)}
                    className="text-xs text-primary hover:underline mt-1"
                  >
                    {isExpanded ? 'Show less' : 'Show more'}
                  </button>
                )}
                {post.symbols.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {post.symbols.map(sym => (
                      <Badge key={sym} variant="outline" className="text-[10px] border-primary/30 text-primary">
                        ${sym}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-destructive border-destructive/30 hover:bg-destructive/10 shrink-0"
                    disabled={isDeleting}
                  >
                    {isDeleting ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Trash2 className="h-3.5 w-3.5" />
                    )}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="glass-card border-border/50">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Post</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to permanently delete this post? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      onClick={() => {
                        deletePost.mutate(BigInt(idx), {
                          onSuccess: () => toast.success('Post deleted successfully'),
                          onError: (err) => toast.error(`Failed to delete: ${(err as Error).message}`),
                        });
                      }}
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── News Editor Tab ──────────────────────────────────────────────────────────

interface EditArticleForm {
  title: string;
  summary: string;
  sentimentScore: string;
}

function NewsEditorTab() {
  const { data: articles, isLoading, error } = useGetNewsArticles();
  const updateArticle = useAdminUpdateNewsArticle();
  const [editingArticle, setEditingArticle] = useState<NewsArticle | null>(null);
  const [form, setForm] = useState<EditArticleForm>({ title: '', summary: '', sentimentScore: '0' });
  const [validationError, setValidationError] = useState('');

  const openEdit = (article: NewsArticle) => {
    setEditingArticle(article);
    setForm({
      title: article.title,
      summary: article.summary,
      sentimentScore: (Number(article.score) / 10).toFixed(1),
    });
    setValidationError('');
  };

  const handleSave = () => {
    const score = parseFloat(form.sentimentScore);
    if (isNaN(score) || score < -1.0 || score > 1.0) {
      setValidationError('Sentiment score must be between -1.0 and 1.0');
      return;
    }
    if (!editingArticle) return;

    updateArticle.mutate(
      {
        id: editingArticle._id,
        title: form.title,
        summary: form.summary,
        sentimentScore: score,
      },
      {
        onSuccess: () => {
          toast.success('Article updated successfully');
          setEditingArticle(null);
        },
        onError: (err) => toast.error(`Update failed: ${(err as Error).message}`),
      }
    );
  };

  if (error) {
    return (
      <div className="glass-card rounded-2xl p-8 text-center">
        <AlertTriangle className="h-10 w-10 text-destructive mx-auto mb-3" />
        <p className="text-destructive font-medium">Failed to load articles</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {isLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="glass-card rounded-2xl p-4">
              <Skeleton className="h-4 w-64 mb-2" />
              <Skeleton className="h-3 w-full mb-1" />
              <Skeleton className="h-3 w-1/2" />
            </div>
          ))
        ) : !articles || articles.length === 0 ? (
          <div className="glass-card rounded-2xl p-12 text-center">
            <Newspaper className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-muted-foreground">No articles found</p>
          </div>
        ) : (
          articles.map((article: NewsArticle) => {
            const score = Number(article.score) / 10;
            const sentimentColor =
              score > 0 ? 'text-emerald-400' : score < 0 ? 'text-red-400' : 'text-yellow-400';

            return (
              <div key={article._id.toString()} className="glass-card rounded-2xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-xs text-muted-foreground">{formatDate(article.date)}</span>
                      <span className={`text-xs font-mono font-medium ${sentimentColor}`}>
                        Score: {score.toFixed(1)}
                      </span>
                    </div>
                    <h4 className="font-semibold text-foreground text-sm mb-1 line-clamp-1">{article.title}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-2">{article.summary}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {article.symbols.map(sym => (
                        <Badge key={sym} variant="outline" className="text-[10px] border-primary/30 text-primary">
                          ${sym}
                        </Badge>
                      ))}
                      <Badge
                        variant="outline"
                        className={`text-[10px] ${
                          article.sentiment.includes('positive')
                            ? 'border-emerald-500/30 text-emerald-400'
                            : article.sentiment.includes('negative')
                            ? 'border-red-500/30 text-red-400'
                            : 'border-yellow-500/30 text-yellow-400'
                        }`}
                      >
                        {article.sentiment}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-primary/30 text-primary hover:bg-primary/10 shrink-0"
                    onClick={() => openEdit(article)}
                  >
                    <Edit className="h-3.5 w-3.5 mr-1" />
                    Edit
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingArticle} onOpenChange={open => !open && setEditingArticle(null)}>
        <DialogContent className="glass-card border-border/50 max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display">Edit Article</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-foreground">Title</label>
              <Input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                className="bg-secondary/40 border-border/50"
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground">Summary</label>
                <span className="text-xs text-muted-foreground">{form.summary.length} chars</span>
              </div>
              <Textarea
                value={form.summary}
                onChange={e => setForm(f => ({ ...f, summary: e.target.value }))}
                rows={4}
                className="bg-secondary/40 border-border/50 resize-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-foreground">
                Sentiment Score <span className="text-muted-foreground font-normal">(-1.0 to 1.0)</span>
              </label>
              <Input
                type="number"
                step="0.1"
                min="-1"
                max="1"
                value={form.sentimentScore}
                onChange={e => {
                  setForm(f => ({ ...f, sentimentScore: e.target.value }));
                  setValidationError('');
                }}
                className="bg-secondary/40 border-border/50"
              />
              {validationError && (
                <p className="text-xs text-destructive">{validationError}</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" className="border-border/50">Cancel</Button>
            </DialogClose>
            <Button
              onClick={handleSave}
              disabled={updateArticle.isPending}
              className="btn-violet"
            >
              {updateArticle.isPending ? (
                <><Loader2 className="h-4 w-4 animate-spin mr-2" />Saving…</>
              ) : (
                'Save Changes'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ─── Analytics Tab ────────────────────────────────────────────────────────────

function AnalyticsTab() {
  const { data: stats, isLoading: statsLoading } = useAdminGetPlatformStats();
  const { data: leaderboard, isLoading: lbLoading } = useGetPublicLeaderboard();
  const { data: articles, isLoading: articlesLoading } = useGetNewsArticles();

  const topUsers = useMemo(() => {
    if (!leaderboard) return [];
    return [...leaderboard]
      .sort((a, b) => b.accuracyRate - a.accuracyRate)
      .slice(0, 10)
      .map(u => ({
        name: u.displayName.length > 12 ? u.displayName.slice(0, 12) + '…' : u.displayName,
        accuracy: Math.round(u.accuracyRate * 100),
      }));
  }, [leaderboard]);

  const sentimentDist = useMemo(() => {
    if (!articles) return [];
    let positive = 0, neutral = 0, negative = 0;
    articles.forEach(a => {
      const s = Number(a.score);
      if (s > 0) positive++;
      else if (s < 0) negative++;
      else neutral++;
    });
    return [
      { name: 'Positive', value: positive, color: '#34d399' },
      { name: 'Neutral', value: neutral, color: '#fbbf24' },
      { name: 'Negative', value: negative, color: '#f87171' },
    ].filter(d => d.value > 0);
  }, [articles]);

  const kpis = [
    {
      label: 'Total Users',
      value: stats?.totalUsers,
      icon: <Users className="h-4 w-4 text-primary" />,
      color: 'bg-primary/10',
    },
    {
      label: 'Total Posts',
      value: stats?.totalPosts,
      icon: <MessageSquare className="h-4 w-4 text-lime" />,
      color: 'bg-lime/10',
    },
    {
      label: 'Total Predictions',
      value: stats?.totalPredictions,
      icon: <TrendingUp className="h-4 w-4 text-cyan-400" />,
      color: 'bg-cyan-400/10',
    },
    {
      label: 'News Articles',
      value: stats?.totalNewsArticles,
      icon: <FileText className="h-4 w-4 text-amber-400" />,
      color: 'bg-amber-400/10',
    },
    {
      label: 'Market Alerts',
      value: stats?.totalMarketAlerts,
      icon: <Bell className="h-4 w-4 text-red-400" />,
      color: 'bg-red-400/10',
    },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {kpis.map(kpi => (
          <KpiCard
            key={kpi.label}
            label={kpi.label}
            value={kpi.value}
            icon={kpi.icon}
            color={kpi.color}
            loading={statsLoading}
          />
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Bar Chart: Top Users by Accuracy */}
        <div className="glass-card rounded-2xl p-5">
          <h3 className="font-display font-semibold text-foreground mb-4 text-sm">
            Top 10 Users by Prediction Accuracy
          </h3>
          {lbLoading ? (
            <Skeleton className="h-48 w-full" />
          ) : topUsers.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              No leaderboard data
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={topUsers} margin={{ top: 4, right: 8, left: -20, bottom: 40 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.025 275 / 0.3)" />
                <XAxis
                  dataKey="name"
                  tick={{ fill: 'oklch(0.56 0.025 275)', fontSize: 10 }}
                  angle={-35}
                  textAnchor="end"
                  interval={0}
                />
                <YAxis
                  tick={{ fill: 'oklch(0.56 0.025 275)', fontSize: 10 }}
                  domain={[0, 100]}
                  tickFormatter={v => `${v}%`}
                />
                <Tooltip
                  contentStyle={{
                    background: 'oklch(0.16 0.022 275 / 0.95)',
                    border: '1px solid oklch(0.28 0.025 275 / 0.5)',
                    borderRadius: '8px',
                    color: 'oklch(0.94 0.008 275)',
                    fontSize: '12px',
                  }}
                  formatter={(v: number) => [`${v}%`, 'Accuracy']}
                />
                <Bar dataKey="accuracy" fill="oklch(0.65 0.26 300)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Pie Chart: Sentiment Distribution */}
        <div className="glass-card rounded-2xl p-5">
          <h3 className="font-display font-semibold text-foreground mb-4 text-sm">
            News Sentiment Distribution
          </h3>
          {articlesLoading ? (
            <Skeleton className="h-48 w-full" />
          ) : sentimentDist.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
              No article data
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={sentimentDist}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {sentimentDist.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: 'oklch(0.16 0.022 275 / 0.95)',
                    border: '1px solid oklch(0.28 0.025 275 / 0.5)',
                    borderRadius: '8px',
                    color: 'oklch(0.94 0.008 275)',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  formatter={(value) => (
                    <span style={{ color: 'oklch(0.56 0.025 275)', fontSize: '12px' }}>{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Admin Page ───────────────────────────────────────────────────────────────

type AdminTab = 'users' | 'posts' | 'news' | 'analytics';

const TABS: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
  { id: 'users', label: 'User Management', icon: <Users className="h-4 w-4" /> },
  { id: 'posts', label: 'Post Moderation', icon: <MessageSquare className="h-4 w-4" /> },
  { id: 'news', label: 'News Editor', icon: <Newspaper className="h-4 w-4" /> },
  { id: 'analytics', label: 'Analytics', icon: <BarChart2 className="h-4 w-4" /> },
];

export default function AdminPage() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: profile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const [activeTab, setActiveTab] = useState<AdminTab>('users');

  // Loading state
  if (isInitializing || profileLoading || !isFetched) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading admin panel…</p>
        </div>
      </div>
    );
  }

  // Not authenticated
  if (!identity) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 px-4">
        <div className="glass-card rounded-2xl p-10 text-center max-w-sm w-full">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
            <Shield className="h-8 w-8 text-destructive" />
          </div>
          <h2 className="font-display text-2xl font-bold text-foreground mb-2">Login Required</h2>
          <p className="text-muted-foreground text-sm">
            Please log in to access the admin panel.
          </p>
        </div>
      </div>
    );
  }

  // Not admin
  if (!profile?.isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-6 px-4">
        <div className="glass-card rounded-2xl p-10 text-center max-w-sm w-full">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
            <Shield className="h-8 w-8 text-destructive" />
          </div>
          <h2 className="font-display text-2xl font-bold text-foreground mb-2">403 — Access Denied</h2>
          <p className="text-muted-foreground text-sm">
            You do not have administrator privileges to access this panel.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2.5 rounded-xl bg-primary/15 border border-primary/25">
          <Shield className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Admin Panel</h1>
          <p className="text-sm text-muted-foreground">
            Manage users, moderate content, and view platform analytics
          </p>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="flex items-center gap-1 p-1 glass-card rounded-2xl w-fit flex-wrap">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
              activeTab === tab.id
                ? 'text-foreground bg-primary/15 shadow-[0_0_0_1px_oklch(0.65_0.26_300/0.3)]'
                : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
            }`}
          >
            {tab.icon}
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="animate-enter">
        {activeTab === 'users' && <UserManagementTab />}
        {activeTab === 'posts' && <PostModerationTab />}
        {activeTab === 'news' && <NewsEditorTab />}
        {activeTab === 'analytics' && <AnalyticsTab />}
      </div>
    </div>
  );
}
