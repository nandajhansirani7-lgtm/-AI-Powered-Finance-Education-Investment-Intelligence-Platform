# Specification

## Summary
**Goal:** Add a full-featured Admin Panel to the FinanceIQ Platform, enabling authorized admins to manage users, moderate community posts, edit news articles, and view platform analytics.

**Planned changes:**
- Extend the Motoko backend user profile record with `isAdmin` (Bool, default false) and `banned` (Bool) fields
- Add a hardcoded superadmin `assignAdmin(principal)` endpoint restricted to the canister deployer
- Implement admin-only backend endpoints: `adminGetAllUsers`, `adminBanUser`, `adminUnbanUser`, `adminDeletePost`, `adminUpdateNewsArticle`, and `adminGetPlatformStats`; all verify `isAdmin = true` on the caller or return `#NotAuthorized`
- Add React Query hooks in `useQueries.ts` for all admin operations (`useAdminGetAllUsers`, `useAdminBanUser`, `useAdminUnbanUser`, `useAdminDeletePost`, `useAdminUpdateNewsArticle`, `useAdminGetPlatformStats`), each invalidating relevant caches on success and surfacing auth errors
- Create `AdminPage.tsx` at route `/admin` with a 403 access-denied gate for non-admins, containing four tabs: User Management, Post Moderation, News Editor, and Analytics — all styled with `GlassCard` and the platform's glassmorphism design tokens
- **User Management tab:** searchable, paginated table of all users showing principal, display name, creation date, prediction accuracy, learning progress, and ban status; per-row Ban/Unban buttons with inline feedback; banned rows visually distinguished
- **Post Moderation tab:** list of all community posts with author, truncated content (expandable), tags, vote count, and timestamp; per-post Delete button with confirmation dialog and immediate list removal on success
- **News Editor tab:** list of all news articles with title, summary, date, symbols, and sentiment score; per-article Edit button opening a pre-populated form; save calls `useAdminUpdateNewsArticle`; sentiment score validated to [-1.0, 1.0]
- **Analytics tab:** five KPI cards (total users, posts, predictions, news articles, market alerts) with number-tick animations; bar chart of top 10 users by prediction accuracy; pie/donut chart of news sentiment distribution
- Add an Admin nav link to `TopNav.tsx` visible only to `isAdmin = true` users, styled with a shield icon/accent glow, routing to `/admin`
- Register the `/admin` route in `App.tsx` (TanStack Router), redirecting unauthenticated users to the login flow

**User-visible outcome:** Admin users see an "Admin" link in the top navigation that opens a protected admin panel with tools to manage users (ban/unban), moderate forum posts (delete), edit news articles, and review platform-wide analytics with charts and KPI counters.
