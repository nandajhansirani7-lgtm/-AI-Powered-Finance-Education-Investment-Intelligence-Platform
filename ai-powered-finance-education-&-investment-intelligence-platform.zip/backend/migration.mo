import Map "mo:core/Map";
import Principal "mo:core/Principal";

module {
  type UserProfileOld = {
    displayName : Text;
    lessonsCompleted : Nat;
    predictionAccuracy : Float;
    portfolioRef : ?Nat;
    passwordHash : ?Text;
  };

  type OldActor = {
    userProfiles : Map.Map<Principal, UserProfileOld>;
  };

  type UserProfileNew = {
    displayName : Text;
    lessonsCompleted : Nat;
    predictionAccuracy : Float;
    portfolioRef : ?Nat;
    passwordHash : ?Text;
    isAdmin : Bool;
    banned : Bool;
  };

  type NewActor = {
    userProfiles : Map.Map<Principal, UserProfileNew>;
  };

  public func run(old : OldActor) : NewActor {
    let newUserProfiles = old.userProfiles.map<Principal, UserProfileOld, UserProfileNew>(
      func(_, oldUserProfile) {
        {
          oldUserProfile with
          isAdmin = false;
          banned = false;
        };
      }
    );
    { userProfiles = newUserProfiles };
  };
};
